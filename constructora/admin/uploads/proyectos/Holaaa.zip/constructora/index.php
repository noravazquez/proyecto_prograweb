<?php
include_once("admin/views/header.php");
include_once("admin/views/menu.php");
include_once("admin/views/footer.php");
?>