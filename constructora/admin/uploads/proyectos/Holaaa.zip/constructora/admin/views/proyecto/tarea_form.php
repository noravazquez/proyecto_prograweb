<h1 class="text-center">Agregar tarea al proyecto:
    <?php echo $data[0]['proyecto']; ?>
</h1>

    