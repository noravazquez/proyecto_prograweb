<div class="alert alert-<?php echo $color ?>" role="alert">
    <?php echo $msg ?>
</div>