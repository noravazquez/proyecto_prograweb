<?php 
include_once("views/header.php");
include_once("views/menu.php");
include_once("views/footer.php");
?>
