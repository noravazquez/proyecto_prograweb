<?php
echo "Hola mundo";
?>