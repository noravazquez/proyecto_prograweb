<?php
//DATA BASE
define("DBDRIVER","mysql");
define("DBHOST",'127.0.0.1');
define("DBNAME","constructora");
define("DBUSER","constructora");
define("DBPASS","123");
define("DBPORT","33060"); 
?>