<?php
include("views/header.php");
include("views/menu.php");
include("views/footer.php");
?>